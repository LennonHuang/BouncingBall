﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Polygon_Test
{
    public partial class PolygonView : UserControl
    {
        
        private int _velocity;
        private Color _Color;

        //center position
        private Point centre;
        private int x;
        private int y;
        //radius of the ball
        private double radius = (20.0) / 2.0;
        //velocity information
        private double velo_x;//x-dircetion unit
        private double velo_y;//y-direction unit
        private double theta;
        public int velocity//Magnitude of the velocity.

        {
            get { return _velocity; }
            set
            {
                _velocity = value;
                Invalidate();
            }
        }


        public Color Color
        {
            get { return _Color; }
            set
            {
                _Color = value;
                Invalidate();
            }
        }

        //Constructor
        public PolygonView()
        {
            //Smooth the motion
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
            this.UpdateStyles();
            //initialize the state.
            _velocity = 5;
            _Color = Color.DarkGray;
            InitializeComponent();
            //initialize at an random direction.
            Random rn = new Random();
            theta = rn.Next(0,360);
            velo_x = Math.Cos(theta);
            velo_y = Math.Sin(theta);
            //User Rectangle.
            Rectangle rc = ClientRectangle;
            //Start at the center of the rectangle.
            x = Convert.ToInt16((rc.Left + rc.Right) / 2);
            y = Convert.ToInt16((rc.Top + rc.Bottom) / 2);
        }

        //draw the ball using the polygon code in the previous lecture.
        private void PolygonView_Paint(object sender, PaintEventArgs e)
        {
            Graphics gfx = e.Graphics;
            gfx.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Pen pen = new Pen(_Color, 10);
            pen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
            double arcSize = Math.PI * 2.0 / 100;
            Point start = new Point(centre.X, centre.Y - (int)radius);
            for(int i = 1; i <= 100; i++)
            {
                Point end = new Point(centre.X + (int)(radius * Math.Sin(arcSize * i)),
                    centre.Y - (int)(radius * Math.Cos(arcSize * i)));
                gfx.DrawLine(pen, start, end);
                start = end;
            }
        }

        //MoveBall action for the timer.
        private void MoveBall()
        {
            //Predict the next position and see whether we should change the motion direction.
            x += Convert.ToInt16(velo_x*velocity);
            if (x + radius+20 >= ClientSize.Width || x - radius-10 < 0)
            {
                velo_x = -velo_x;
            }
            y += Convert.ToInt16(velo_y*velocity); 
            if (y + radius+20 >= ClientSize.Height || y - radius-10 < 0)
            {
                velo_y = -velo_y;
            }
            //Update the centre of the ball.
            centre = new Point(x, y);

        }
        private void PolygonView_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MoveBall();
            Invalidate();
        }
    }
}
